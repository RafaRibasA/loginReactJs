function Imagem(props){
    return(<img src={props.imagem}  class="img-fluid w-25"></img>);
}

export default Imagem;