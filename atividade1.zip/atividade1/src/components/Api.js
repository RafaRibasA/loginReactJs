import React from "react";
import { useParams } from "react-router-dom"
import Random from "./Random";

export default function Api (){
  
  const [pessoa, setPessoa] = React.useState({});

  function Carregar() {
    fetch('https://randomuser.me/api')
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        setPessoa(data);
      });
  }

     React.useEffect(()=>{
            Carregar();
    },[]);

        
    if(pessoa.name != null || pessoa.name !== "")
    {
        return (
            
            <div class=" col-md-12 text-center d-flex align-items-center justify-content-center">
            
            <div class="border-white border border-4 w-75 p-3 bg-dark">
            
                <div class="row justify-content-around">
            
                <div class=" d-flex justify-content-center">
                                
                </div>
            
                <Random  nome={pessoa.results?.map(nome => nome.name.first)} email={pessoa.results?.map(email => email.email)} niver={pessoa.results?.map(niver => niver.dob.date)}  tel={pessoa.results?.map(tel => tel.phone)} foto={pessoa.results?.map(foto => foto.picture.large)} end={pessoa.results?.map(end => end.location.street.name)}/>
            
                </div>
            
            </div>
            </div>
            
        );
  }else {
    <h1>Erro 404</h1>
  }
}