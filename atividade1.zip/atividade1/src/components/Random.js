import Imagem from "./Imagem";
import Desc from "./Desc";

function Random(props){
    return(
        <div className="row d-flex justify-content-center text-center">

            <div className="col-4" class="text-center">

            </div>

            <div className="col-8" class="text-center">

                <Desc nome={props.nome} email={props.email} niver={props.niver} end = {props.end} tel = {props.tel} foto = {props.foto}/>
            
            </div>
        
        </div>
      
    );

}



export default Random;