export default function Home(){
    return (

        <div>
            <h1>Rafael Ribas Albuquerque</h1>
            <h1>Bcc</h1>
        </div>

    );
}