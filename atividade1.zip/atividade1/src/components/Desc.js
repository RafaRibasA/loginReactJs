import Imagem from "./Imagem"

function Desc(props){
    return(
        <>
        <Imagem imagem={props.foto}/>
        <h1 class="text-capitalize text-center">{props.nome}</h1>

        <div class="text-center align-items-center d-flex justify-content-around pt-5">

            <h3>email: {props.email}</h3>
            
            <h3>niver: {props.niver}</h3>
            
            
            <div class = "justify-content-around">
               
                <h4>Telefone: {props.tel}</h4>
               
                <h4>Rua: {props.end}</h4>
           
            </div>

        </div>

        </>);
        }

export default Desc;