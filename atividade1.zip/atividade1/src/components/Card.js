import React, { useCallback } from "react";
import { CardContext } from "../CardContext";
import { useContext } from "react";

export default function Card(){
    const pessoa = useContext(CardContext);
    return (
        <div>
            
            <h1>{pessoa.nome}</h1>

        </div>

    );
}