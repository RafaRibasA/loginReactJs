export const pessoas = [
    { nome: "rafael", email: "rafa", niver: "r", endereco: "r", tel: "r", foto: "r"}
];