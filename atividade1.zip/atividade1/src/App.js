import { Routes, Route} from 'react-router-dom'
import Home from './components/Home';
import {pessoas} from './Data/pessoas'
import { CardContext } from './CardContext';
import Card from './components/Card';
import Random from './components/Random';
import Api from './components/Api';
import Error from './components/Error'

function App() {
  return (
    <div className="App">
     <CardContext.Provider value ={pessoas}>
      <Routes>

        <Route path="/" element={<Home/>}/>

        <Route path='/random' element={<Api/>}/>
        <Route path='*' element={<Error/>}/>

      </Routes>
    </CardContext.Provider>
    </div>
  );
}

export default App;
